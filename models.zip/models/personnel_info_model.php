<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

require_once(FUEL_PATH . 'models/base_module_model.php');

class Personnel_info_model extends Base_module_model {

    // read more about models in the user guide to get a list of all properties. Below is a subset of the most common:

    public $record_class = 'Personnel_info_item'; // the name of the record class (if it can't be determined)
    public $filters = array(); // filters to apply to when searching for items
    public $required = array('name_of_employee'); // an array of required fields. If a key => val is provided, the key is name of the field and the value is the error message to display
    public $foreign_keys = array('user_id' => array('fuel/fuel_users_model', 'where' => array('active' => 'yes')),
         'designation_id' => array('designation_model'),
        'designation_id' => array('designation_model'),
        'division_id' => array('division_model'),
        'home_dist_id' => array('districts_model'),
    ); // map foreign keys to table models
    public $linked_fields = array(); // fields that are linked meaning one value helps to determine another. Key is the field, value is a function name to transform it. (e.g. array('slug' => 'title'), or array('slug' => arry('name' => 'strtolower')));
    public $boolean_fields = array(); // fields that are tinyint and should be treated as boolean
    public $unique_fields = array('employee_id', 'user_id'); // fields that are not IDs but are unique. Can also be an array of arrays for compound keys
    public $parsed_fields = array(); // fields to automatically parse
    public $serialized_fields = array(); // fields that contain serialized data. This will automatically serialize before saving and unserialize data upon retrieving
    public $has_many = array(); // keys are model, which can be a key value pair with the key being the module and the value being the model, module (if not specified in model parameter), relationships_model, foreign_key, candidate_key
    public $belongs_to = array(); // keys are model, which can be a key value pair with the key being the module and the value being the model, module (if not specified in model parameter), relationships_model, foreign_key, candidate_key
    public $formatters = array(); // an array of helper formatter functions related to a specific field type (e.g. string, datetime, number), or name (e.g. title, content) that can augment field results
    public $display_unpublished_if_logged_in = FALSE;
    protected $friendly_name = ''; // a friendlier name of the group of objects
    protected $singular_name = ''; // a friendly singular name of the object

    function __construct() {
        parent::__construct('personnel_info'); // table name
    }

    function list_items($limit = NULL, $offset = NULL, $col = 'precedence', $order = 'desc', $just_count = FALSE) {

        $this->db->join('designation', 'designation.id = personnel_info.designation_id', 'left');
        $this->db->join('division', 'division.id = personnel_info.division_id', 'left');
        $this->db->join('districts', 'districts.id = personnel_info.home_dist_id', 'left');
        $this->db->select('personnel_info.*,designation.name as designation_id,division.name as division_id,districts.name as home_dist_id', FALSE);
        $CI = & get_instance();
        $user = $CI->fuel->auth->user_data();
        if (!$CI->fuel->auth->has_permission('personnel_info')) {
            $this->db->where(array('user_id' => $user['id']));
        }

        $data = parent::list_items($limit, $offset, $col, $order, $just_count);


        return $data;
    }

    function form_fields($values = null) {
        $CI = & get_instance();
        $fields = parent::form_fields();
        foreach ($fields as $key => $field) {
            if (!$field['null']  && $field['name'] !='id') {
                 $this->required[]= $field['name'];
                $fields[$key]['required']= true;
            }
        }
        $user = $CI->fuel_auth->user_data();
        $this->load->model(array('personnel_family_model', 'academic_info_model', 'in_service_training_info_model',
            'other_training_info_model', 'nominee_of_employee_model', 'place_of_posting_model',
            'promotion_model', 'publications_model', 'language_proficency_model',
            'honours_and_award_model', 'computer_proficiency_model', 'country_model'));

        if (!empty($values['id'])) {
            $where['employee_id'] = $values['id'];
            $personnel_family_min = ( $this->personnel_family_model->record_count($where));
            $academic_info_min = ( $this->academic_info_model->record_count($where));
            $in_service_training_info_min = ( $this->in_service_training_info_model->record_count($where));

            $other_training_info_min = ( $this->other_training_info_model->record_count($where));
            $nominee_of_employee_min = ( $this->nominee_of_employee_model->record_count($where));
            $place_of_posting_min = ( $this->place_of_posting_model->record_count($where));
            $promotion_min = ( $this->promotion_model->record_count($where));
            $publications_min = ( $this->publications_model->record_count($where));
            $language_proficency_min = ( $this->language_proficency_model->record_count($where));
            $honours_and_award_min = ( $this->honours_and_award_model->record_count($where));
            $computer_proficiency_min = ( $this->computer_proficiency_model->record_count($where));
        } else {
            $personnel_family_min = 1;
            $academic_info_min = 1;
            $in_service_training_info_min = 1;
            $other_training_info_min = 1;
            $nominee_of_employee_min = 1;
            $place_of_posting_min = 1;
            $promotion_min = 1;
            $publications_min = 1;
            $language_proficency_min = 1;
            $honours_and_award_min = 1;
            $academic_info_min = 1;
            $computer_proficiency_min = 1;
        }

        $country = $this->country_model->options_list('id', 'name');
        $designation = $this->designation_model->options_list('id', 'name');
        $fields['personnel_family_section'] = array('label' => 'Family', 'type' => 'section', 'class' => 'tab');

        $fields['personnel_family'] = array('display_label' => FALSE,
            'row_class' => 'personnel_family',
            'add_extra' => false,
            'init_display' => 'all',
            'repeatable' => TRUE,
            'type' => 'template',
            'min' => $personnel_family_min,
            'label' => 'Family',
            'title_field' => 'relationship',
            'non_sortable' => true,
            'fields' => array(
                'id' => array('type' => 'hidden'),
                'relationship' => array(),
                'name_of_spouse' => array('required' => true, 'label'=> 'Name'),
                'occupation' => array('required' => true),
                'date_of_birth' => array('type' => 'date'),
                'remarks' => array(),
            ),
        );

        $fields['academic_info_section'] = array('label' => 'Academic', 'type' => 'section', 'class' => 'tab');

        for ($i = date('Y'); $i >= 1960; $i--) {
            $passing_year[$i] = $i;
        }
        $fields['academic_info'] = array('display_label' => FALSE,
            'row_class' => 'academic_info',
            'add_extra' => false,
            'init_display' => 'all',
            'repeatable' => TRUE,
            'type' => 'template',
            'min' => $academic_info_min,
            'label' => 'Family',
            'title_field' => 'name_of_examination',
            'non_sortable' => true,
            'fields' => array(
                'id' => array('type' => 'hidden'),
                'name_of_examination' => array('required' => true),
                'board_or_university' => array('required' => true),
                'institution' => array('required' => true),
                'result_type' => array('type' => 'enum', 'row_class' => 'academic_info_type', 'mode' => 'select', 'options' => array('Class', 'Division', 'CGPA')),
                'result' => array('required' => true),
                'passing_year' => array('type' => 'enum', 'row_class' => 'academic_info_year_type', 'mode' => 'select', 'options' => $passing_year),
            ),
        );

        $fields['in_service_training_info_section'] = array('label' => 'In Service Training', 'type' => 'section', 'class' => 'tab');

        $fields['in_service_training_info'] = array('display_label' => FALSE,
            'row_class' => 'in_service_training_info',
            'add_extra' => false,
            'init_display' => 'all',
            'repeatable' => TRUE,
            'type' => 'template',
            'min' => $in_service_training_info_min,
            'label' => 'Family',
            'title_field' => 'subject',
            'non_sortable' => true,
            'fields' => array(
                'id' => array('type' => 'hidden'),
                'subject' => array('required' => true),
                'institute' => array('required' => true),
                'country_id' => array('type' => 'select', 'row_class' => 'in_service_training_info_type', 'mode' => 'select', 'options' => $country),
                'start_date' => array('type' => 'date'),
                'end_date' => array('type' => 'date'),
            ),
        );

        $fields['other_training_info_section'] = array('label' => 'Other Training', 'type' => 'section', 'class' => 'tab');

        $fields['other_training_info'] = array('display_label' => FALSE,
            'row_class' => 'other_training_info',
            'add_extra' => false,
            'init_display' => 'all',
            'repeatable' => TRUE,
            'type' => 'template',
            'min' => $other_training_info_min,
            'label' => 'other_training_info',
            'title_field' => 'subject',
            'non_sortable' => true,
            'fields' => array(
                'id' => array('type' => 'hidden'),
                'country_visited_id' => array('type' => 'select', 'row_class' => 'other_training_info_type', 'mode' => 'select', 'options' => $country),
                'purpose' => array('required' => true),
                'financed_by' => array('required' => true),
                'start_date' => array('type' => 'date'),
                'end_date' => array('type' => 'date'),
                'remarks' => array(),
            ),
        );

        $fields['nominee_of_employee_section'] = array('label' => 'Nominee of employee', 'type' => 'section', 'class' => 'tab');

        $fields['nominee_of_employee'] = array('display_label' => FALSE,
            'row_class' => 'nominee_of_employee',
            'add_extra' => false,
            'init_display' => 'all',
            'repeatable' => TRUE,
            'type' => 'template',
            'min' => $nominee_of_employee_min,
            'label' => 'nominee_of_employee',
            'title_field' => 'subject',
            'non_sortable' => true,
            'fields' => array(
                'id' => array('type' => 'hidden'),
                'name_of_the_person' => array('required' => true),
                'relationship' => array('required' => true),
                'nominee_per_of_gratuity' => array('label' => 'nominee_%_of_gratuity', 'required' => true),
                'nominee_per_of_pf' => array('label' => 'nominee_%_of_pf'),
                'nominee_per_of_group_insurance' => array('label' => 'nominee_%_of_group_insurance'),
                'nominee_per_of_benevolent_fund' => array('label' => 'nominee % of benevolent fund'),
            ),
        );

        $fields['place_of_posting_section'] = array('label' => 'Place of Posting', 'type' => 'section', 'class' => 'tab');

        $fields['place_of_posting'] = array('display_label' => FALSE,
            'row_class' => 'place_of_posting',
            'add_extra' => false,
            'init_display' => 'all',
            'repeatable' => TRUE,
            'type' => 'template',
            'min' => $place_of_posting_min,
            'label' => 'place_of_posting',
            'title_field' => 'subject',
            'non_sortable' => true,
            'fields' => array(
                'id' => array('type' => 'hidden'),
                'designation_id' => array('type' => 'select', 'row_class' => 'place_of_posting_type', 'mode' => 'select', 'options' => $designation),
                'name_of_office' => array('required' => true),
                'start_date' => array('type' => 'date'),
                'end_date' => array('type' => 'date'),
                'remarks' => array(),
            ),
        );

        $fields['promotion_section'] = array('label' => 'Promotion', 'type' => 'section', 'class' => 'tab');

        $fields['promotion'] = array('display_label' => FALSE,
            'row_class' => 'promotion',
            'add_extra' => false,
            'init_display' => 'all',
            'repeatable' => TRUE,
            'type' => 'template',
            'min' => $promotion_min,
            'label' => 'promotion',
            'title_field' => 'subject',
            'non_sortable' => true,
            'fields' => array(
                'id' => array('type' => 'hidden'),
                'date_of_promotion' => array('type' => 'date'),
                'post' => array('required' => true),
                'new_scale' => array('required' => true),
                'joining_date' => array('type' => 'date'),
                'remarks' => array(),
            ),
        );




        $fields['publications_section'] = array('label' => 'publications', 'type' => 'section', 'class' => 'tab');

        $fields['publications'] = array('display_label' => FALSE,
            'row_class' => 'publications',
            'add_extra' => false,
            'init_display' => 'all',
            'repeatable' => TRUE,
            'type' => 'template',
            'min' => $publications_min,
            'label' => 'publications',
            'title_field' => 'subject',
            'non_sortable' => true,
            'fields' => array(
                'id' => array('type' => 'hidden'),
                'name' => array('required' => true),
                'type' => array('type' => 'enum', 'row_class' => 'publications_type', 'mode' => 'select', 'options' => array('Books', 'Monograph', 'News & Periodicals', 'Professional Journals')),
                'count' => array('type' => 'number'),
            ),
        );


        $fields['computer_proficiency_section'] = array('label' => 'Computer Proficiency', 'type' => 'section', 'class' => 'tab');

        $fields['computer_proficiency'] = array('display_label' => FALSE,
            'row_class' => 'computer_proficiency',
            'add_extra' => false,
            'init_display' => 'all',
            'repeatable' => TRUE,
            'type' => 'template',
            'min' => $computer_proficiency_min,
            'label' => 'computer_proficiency',
            'title_field' => 'subject',
            'non_sortable' => true,
            'fields' => array(
                'id' => array('type' => 'hidden'),
                'name' => array('required' => true),
                'type' => array('type' => 'enum', 'row_class' => 'publications_type', 'mode' => 'select', 'options' => array('Operating System', 'MS Office', 'Internet Usage', 'Others')),
            ),
        );


        $fields['language_proficency_section'] = array('label' => 'Language Proficiency', 'type' => 'section', 'class' => 'tab');

        $fields['lang_proficiency'] = array('display_label' => FALSE,
            'row_class' => 'language_proficency',
            'add_extra' => false,
            'init_display' => 'all',
            'repeatable' => TRUE,
            'type' => 'template',
            'min' => $language_proficency_min,
            'label' => 'language_proficency',
            'title_field' => 'subject',
            'non_sortable' => true,
            'fields' => array(
                'id' => array('type' => 'hidden'),
                'name' => array('required' => true),),
        );


        $fields['honours_and_award_section'] = array('label' => 'Honours & Award', 'type' => 'section', 'class' => 'tab');

        $fields['honours_and_award'] = array('display_label' => FALSE,
            'row_class' => 'honours_and_award',
            'add_extra' => true,
            'init_display' => 'all',
            'repeatable' => TRUE,
            'type' => 'template',
            'min' => $honours_and_award_min,
            'label' => 'honours_and_award',
            'title_field' => 'title_of_award',
            'non_sortable' => true,
            'fields' => array(
                'id' => array('type' => 'hidden'),
                'title_of_award' => array('required' => true),
                'date' => array('type' => 'date'),
            ),
        );

        return $fields;
    }

    function form_fields_front($values = null) {
        $CI = & get_instance();
        $fields = parent::form_fields();
        foreach ($fields as $key => $field) {
            if (!$field['null']) {
                 $this->required[]= $field['name'];
            }
        }

        return $fields;
    }

    public function save($record = NULL, $validate = TRUE, $ignore_on_insert = TRUE, $clear_related = NULL) {
        $this->_check_readonly();
        $CI = & get_instance();

        if (!isset($record))
            $record = $CI->input->post();


        if ($this->_is_nested_array($record)) {
            $saved = TRUE;
            foreach ($record as $rec) {
                if (!$this->save($rec, $validate, $ignore_on_insert, $clear_related)) {
                    $saved = FALSE;
                }
            }
            return $saved;
        } else {
            $fields = array();

            $old_clear_related_on_save = $this->clear_related_on_save;

            if (isset($clear_related)) {
                $this->clear_related_on_save = $clear_related;
            }


            $values = $this->normalize_save_values($record);

            // reset validator here so that all validation set with hooks will not be lost
            $this->validator->reset();

            // clean the data before saving. on_before_clean hook now runs in the clean() method
            $values = $this->on_before_clean($values);

            $data = array();
            $data['personnel_family'] = $values['personnel_family'];
            $data['academic_info'] = $values['academic_info'];
            $data['in_service_training_info'] = $values['in_service_training_info'];
            $data['other_training_info'] = $values['other_training_info'];
            $data['nominee_of_employee'] = $values['nominee_of_employee'];
            $data['place_of_posting'] = $values['place_of_posting'];
            $data['promotion'] = $values['promotion'];
            $data['publications'] = $values['publications'];
            $data['language_proficency'] = $values['lang_proficiency'];
            $data['honours_and_award'] = $values['honours_and_award'];
            $data['computer_proficiency'] = $values['computer_proficiency'];


            $values = $this->clean($values);

            $values = $this->on_before_validate($values);

            // now validate. on_before_validate hook now runs inside validate() method
            $validated = ($validate) ? $this->validate($values) : TRUE;


            if ($validated AND !empty($values)) {
                // now clean the data to be ready for database saving
                $this->db->set($values);

                if ($ignore_on_insert) {
                    // execute on_before_insert/update hook methods
                    $values = $this->on_before_save($values);

                    // process serialized values
                    $values = $this->serialize_field_values($values);

                    if (!$this->_has_key_field_value($values)) {
                        $values = $this->on_before_insert($values);
                    } else {
                        $values = $this->on_before_update($values);
                    }
                    $insert_key = ($this->has_auto_increment) ? $this->key_field : NULL;

                    $this->db->insert_ignore($this->table_name, $values, $insert_key);

                    // execute on_insert/update hook methods
                    $no_key = FALSE;
                    $insert_id = $this->db->insert_id();
                    if (!$this->_has_key_field_value($values) AND $insert_id) {
                        $no_key = TRUE;
                        if (is_string($this->key_field)) {
                            $values[$this->key_field] = $insert_id;
                        }
                        $this->on_after_insert($values);
                    } else {
                        $this->on_after_update($values);
                    }

                    // execute on_insert/update hook methods on the Date_record model if exists
                    if (is_object($record) AND ($record instanceof Data_record)) {
                        if ($no_key) {
                            $record->on_after_insert($values);
                        } else {
                            $record->on_after_update($values);
                        }
                    }
                } else if (!$this->_has_key_field_value($values)) {
                    // execute on_before_insert/update hook methods
                    $values = $this->on_before_save($values);
                    $values = $this->on_before_insert($values);

                    // process serialized values
                    $values = $this->serialize_field_values($values);

                    $this->db->insert($this->table_name, $values);
                    $insert_id = $this->db->insert_id();
                    if (is_string($this->key_field)) {
                        $values[$this->key_field] = $insert_id;
                    }
                    $this->on_after_insert($values);
                    if ($record instanceof Data_record) {
                        $record->on_after_insert($values);
                    }
                } else {
                    $key_field = (array) $this->key_field;
                    foreach ($key_field as $key) {
                        $this->db->where($key, $values[$key]);
                    }

                    $values = $this->on_before_save($values);
                    $values = $this->on_before_update($values);

                    // process serialized values
                    $values = $this->serialize_field_values($values);

                    $this->db->update($this->table_name, $values);
                    $this->on_after_update($values);
                    if ($record instanceof Data_record) {
                        $record->on_after_update();
                    }
                }
            } else {
                return FALSE;
            }

            // returns the key value of the record upon save
            if (isset($insert_id) AND !empty($insert_id)) {
                $return = $insert_id;
            } else {
                if ($record instanceof Data_record) {
                    $key_field = $this->key_field;
                    if (is_string($this->key_field)) {
                        $return = $record->$key_field;
                    } else {
                        $return = array();
                        foreach ($key_field as $key) {
                            $return[$key] = $record->$key;
                        }
                    }
                } else if (is_string($this->key_field) AND !empty($values[$this->key_field])) {
                    $return = $values[$this->key_field];
                } else if (is_array($this->key_field)) {
                    $return = array();
                    foreach ($key_field as $key) {
                        $return[$key] = $values[$key_field];
                    }
                } else {
                    $return = TRUE;
                    // not valid test because a save could happen and no data is changed
                    //return (bool)($this->db->affected_rows()) ? TRUE : FALSE;
                }
            }

            $this->on_after_save($values);

            // set this back to the old value
            $this->clear_related_on_save = $old_clear_related_on_save;

            // check for errors here in case some are thrown in the hooks
            if ($this->has_error()) {
                return FALSE;
            }


            $this->update_related_data(array('personnel' => $values, 'data' => $data));
//            die();
            return $return;
        }
    }

    function update_related_data($values) {
        $data = $values['data'];
//        echo '<pre>';
//        print_r($data);
//
//        echo '</pre>'; 
        $personnel_family = $values['data']['personnel_family'];
        $academic_info = $values['data']['academic_info'];
        $in_service_training_info = $values['data']['in_service_training_info'];
        $other_training_info = $values['data']['other_training_info'];
        $nominee_of_employee = $values['data']['nominee_of_employee'];
        $place_of_posting = $values['data']['place_of_posting'];
        $promotion = $values['data']['promotion'];
        $publications = $values['data']['publications'];
        $language_proficency = $values['data']['language_proficency'];
        $honours_and_award = $values['data']['honours_and_award'];
        $computer_proficiency = $values['data']['computer_proficiency'];



        $where['employee_id'] = $values['personnel']['id'];



        if ($this->personnel_family_model->delete($where)) {
            if (is_array($personnel_family)) {

                foreach ($personnel_family as $key => $value) {
                    if (!$value['name_of_spouse'] && !$value['relationship']) {
                        unset($personnel_family[$key]);
                    } else {
                        unset($personnel_family[$key]['id']);
                        $personnel_family[$key]['employee_id'] = $values['personnel']['id'];
                    }
                }

                if (count($personnel_family) > 0) {
                    $personnel_family_saved = ($this->personnel_family_model->save($personnel_family));

                    if (!$personnel_family_saved) {
                        return false;
                    }
                }
            }
        } else {
            return false;
        }

        if ($this->academic_info_model->delete($where)) {
            if (is_array($academic_info)) {


                foreach ($academic_info as $key => $value) {
                    if (!$value['name_of_examination'] && !$value['board_or_university'] && !$value['institution'] && !$value['result_type'] && !$value['result'] && !$value['passing_year']) {
                        unset($academic_info[$key]);
                    } else {


                        unset($academic_info[$key]['id']);
                        $academic_info[$key]['employee_id'] = $values['personnel']['id'];
                    }
                }

                if (count($academic_info) > 0) {
                    $academic_info_saved = ($this->academic_info_model->save($academic_info));


                    $return = false;
                    if (!$academic_info_saved) {
                        return false;
                    }
                }
            }
        } else {
            return false;
        }

        if ($this->in_service_training_info_model->delete($where)) {
            if (is_array($in_service_training_info)) {


                foreach ($in_service_training_info as $key => $value) {
                    if (!$value['subject'] && !$value['institute'] && !$value['start_date'] && !$value['end_date'] && !$value['country_id']) {
                        unset($in_service_training_info[$key]);
                    } else {


                        unset($in_service_training_info[$key]['id']);
                        $in_service_training_info[$key]['employee_id'] = $values['personnel']['id'];
                    }
                }

                if (count($in_service_training_info) > 0) {
                    $in_service_training_info_saved = ($this->in_service_training_info_model->save($in_service_training_info));
                    $return = false;
                    if (!$in_service_training_info_saved) {
                        return false;
                    }
                }
            }
        } else {
            return false;
        }


        if ($this->other_training_info_model->delete($where)) {
            if (is_array($other_training_info)) {


                foreach ($other_training_info as $key => $value) {
                    if (!$value['country_visited_id'] && !$value['purpose'] && !$value['financed_by'] && !$value['start_date'] && !$value['end_date']) {
                        unset($other_training_info[$key]);
                    } else {


                        unset($other_training_info[$key]['id']);
                        $other_training_info[$key]['employee_id'] = $values['personnel']['id'];
                    }
                }

                if (count($other_training_info) > 0) {
                    $other_training_info_saved = ($this->other_training_info_model->save($other_training_info));
                    $return = false;
                    if (!$other_training_info_saved) {
                        return false;
                    }
                }
            }
        } else {
            return false;
        }

        if ($this->nominee_of_employee_model->delete($where)) {
            if (is_array($nominee_of_employee)) {


                foreach ($nominee_of_employee as $key => $value) {
                    if (!$value['name_of_the_person'] && !$value['relationship'] && !$value['nominee_per_of_gratuity'] && !$value['nominee_per_of_pf'] && !$value['nominee_per_of_group_insurance'] && !$value['nominee_per_of_benevolent_fund']) {
                        unset($nominee_of_employee[$key]);
                    } else {


                        unset($nominee_of_employee[$key]['id']);
                        $nominee_of_employee[$key]['employee_id'] = $values['personnel']['id'];
                    }
                }

                if (count($nominee_of_employee) > 0) {
                    $nominee_of_employee_saved = ($this->nominee_of_employee_model->save($nominee_of_employee));
                    $return = false;
                    if (!$nominee_of_employee_saved) {
                        return false;
                    }
                }
            }
        } else {
            return false;
        }

        if ($this->place_of_posting_model->delete($where)) {
            if (is_array($place_of_posting)) {


                foreach ($place_of_posting as $key => $value) {
                    if (!$value['name_of_office'] && !$value['start_date'] && !$value['end_date']) {
                        unset($place_of_posting[$key]);
                    } else {


                        unset($place_of_posting[$key]['id']);
                        $place_of_posting[$key]['employee_id'] = $values['personnel']['id'];
                    }
                }

                if (count($place_of_posting) > 0) {
                    $place_of_posting_saved = ($this->place_of_posting_model->save($place_of_posting));
                    $return = false;
                    if (!$place_of_posting_saved) {
                        return false;
                    }
                }
            }
        } else {
            return false;
        }



        if ($this->promotion_model->delete($where)) {
            if (is_array($promotion)) {


                foreach ($promotion as $key => $value) {
                    if (!$value['date_of_promotion'] && !$value['post'] && !$value['new_scale'] && !$value['joining_date']) {
                        unset($promotion[$key]);
                    } else {


                        unset($promotion[$key]['id']);
                        $promotion[$key]['employee_id'] = $values['personnel']['id'];
                    }
                }

                if (count($promotion) > 0) {
                    $promotion_saved = ($this->promotion_model->save($promotion));
                    $return = false;
                    if (!$promotion_saved) {
                        return false;
                    }
                }
            }
        } else {
            return false;
        }

        if ($this->publications_model->delete($where)) {
            if (is_array($publications)) {


                foreach ($publications as $key => $value) {
                    if (!$value['name'] && !$value['type'] && !$value['count']) {
                        unset($publications[$key]);
                    } else {


                        unset($publications[$key]['id']);
                        $publications[$key]['employee_id'] = $values['personnel']['id'];
                    }
                }

                if (count($publications) > 0) {
                    $publications_saved = ($this->publications_model->save($publications));
                    $return = false;
                    if (!$publications_saved) {
                        return false;
                    }
                }
            }
        } else {
            return false;
        }

        if ($this->language_proficency_model->delete($where)) {
            if (is_array($language_proficency)) {


                foreach ($language_proficency as $key => $value) {
                    if (!$value['name']) {
                        unset($language_proficency[$key]);
                    } else {


                        unset($language_proficency[$key]['id']);
                        $language_proficency[$key]['employee_id'] = $values['personnel']['id'];
                    }
                }

                if (count($language_proficency) > 0) {
                    $language_proficency_saved = ($this->language_proficency_model->save($language_proficency));
                    $return = false;
                    if (!$language_proficency_saved) {
                        return false;
                    }
                }
            }
        } else {
            return false;
        }



        if ($this->honours_and_award_model->delete($where)) {
            if (is_array($honours_and_award)) {


                foreach ($honours_and_award as $key => $value) {
                    if (!$value['title_of_award'] && !$value['date']) {
                        unset($honours_and_award[$key]);
                    } else {


                        unset($honours_and_award[$key]['id']);
                        $honours_and_award[$key]['employee_id'] = $values['personnel']['id'];
                    }
                }
                if (count($honours_and_award) > 0) {
                    $honours_and_award_saved = ($this->honours_and_award_model->save($honours_and_award));
                    $return = false;
                    if (!$honours_and_award_saved) {
                        return false;
                    }
                }
            }
        } else {
            return false;
        }

        if ($this->computer_proficiency_model->delete($where)) {
            if (is_array($computer_proficiency)) {


                foreach ($computer_proficiency as $key => $value) {
                    if (!$value['name'] && !$value['type']) {
                        unset($computer_proficiency[$key]);
                    } else {


                        unset($computer_proficiency[$key]['id']);
                        $computer_proficiency[$key]['employee_id'] = $values['personnel']['id'];
                    }
                }

                if (count($computer_proficiency) > 0) {
                    $computer_proficiency_saved = ($this->computer_proficiency_model->save($computer_proficiency));
                    $return = false;
                    if (!$computer_proficiency_saved) {
                        return false;
                    }
                }
            }
        } else {
            return false;
        }






        return true;
    }

    function on_before_save($values) {
        parent::on_before_save($values);
        return $values;
    }

    function on_after_save($values) {
        parent::on_after_save($values);
        return $values;
    }

    function _common_query() {
        parent::_common_query();

        // remove if no precedence column is provided
        $this->db->order_by('precedence asc');
    }

}

class Personnel_info_item_model extends Base_module_record {

    // put your record model code here
    public function get_image_path() {
        return img_path('images/personnel_info/' . $this->image);
    }

}